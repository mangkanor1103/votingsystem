<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2021 <a href="https://www.alphacodecamp.com.ng">alphacodecamp</a></strong>
    </div>
    <!-- /.container -->
</footer>